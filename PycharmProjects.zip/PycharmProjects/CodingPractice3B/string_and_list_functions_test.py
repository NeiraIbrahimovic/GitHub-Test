import unittest
from importlib.resources.readers import remove_duplicates

from string_and_list_functions import *

class MyTestCase(unittest.TestCase):
    def test_string_concatenate(self):
        # Test concatenation of 2 strings
        element_1 = "Hello"
        element_2 = "World"
        output_string = concatenate(element_1, element_2)
        self.assertEqual("HelloWorld", output_string, "Concatenation of \'Hello\' and \'World\' should be \'HelloWorld\'")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")

        # Test concatenation of int and string
        element_1 = 1
        element_2 = "Two"
        output_string = concatenate(element_1, element_2)
        self.assertEqual("1Two", output_string, "Concatenation of 1 and \'Two\' should be \'1Two\'")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")

        # Test concatenation of string and float
        element_1 = "Pi is: "
        element_2 = 3.14159265359
        output_string = concatenate(element_1, element_2)
        self.assertEqual("Pi is: 3.14159265359", output_string, "Concatenation of \'Pi is: \' and 3.14159265359 should be \'Pi is: 3.14159265359\'")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")

        # Test concatenation of string and list
        element_1 = "Vowels are: "
        element_2 = ['a', 'e', 'i', 'o', 'u']
        output_string = concatenate(element_1, element_2)
        self.assertEqual("Vowels are: ['a', 'e', 'i', 'o', 'u']", output_string, "Concatenation of \"Vowels are: \" and ['a', 'e', 'i', 'o', 'u'] should be \"Vowels are: ['a', 'e', 'i', 'o', 'u']\"")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")

        # Test concatenation of boolean value and string
        element_1 = True
        element_2 = " is a boolean value"
        output_string = concatenate(element_1, element_2)
        self.assertEqual("True is a boolean value", output_string, "Concatenation of True and \" is a boolean value\" should be \"True is a boolean value\"")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")

        # Test concatenation of tuple and string
        element_1 = (0, 2)
        element_2 = " is a tuple"
        output_string = concatenate(element_1, element_2)
        self.assertEqual("(0, 2) is a tuple", output_string,"Concatenation of (0, 2)) and \" is a tuple\" should be \"(0, 2) is a tuple\"")
        self.assertIsInstance(output_string, str, "Output should be a string data type.")


    def test_string_remove_vowels(self):
        # Test a string with lowercase vowels
        input_string = "Hello World"
        output_string = "Hll Wrld"
        self.assertEqual(output_string, remove_vowels(input_string))

        # Test a string with uppercase vowels
        input_string = "HEllO WOrld"
        self.assertEqual(output_string, remove_vowels(input_string))

        # Test a string with mixed vowels casing
        input_string = "HEllo WOrld"
        self.assertEqual(output_string, remove_vowels(input_string))

        # Test a string with mixed vowels casing and a tab character
        input_string = "HEllo WOrld \t"
        output_string = "Hll Wrld \t"
        self.assertEqual(output_string, remove_vowels(input_string))

        # Test a string without a vowel
        input_string = "Hll Wrld \t"
        output_string = "Hll Wrld \t"
        self.assertEqual(output_string, remove_vowels(input_string))

    def test_string_replace_digits(self):
        #Test a string without a digit. Output should be the same with input string
        input_string = "Brandon Krakowsky"
        output_string = "Brandon Krakowsky"
        self.assertEqual(output_string, replace_digits(input_string))

        #Test a string with digit(s)
        input_string = "I love CIT-5910"
        output_string = "I love CIT-----"
        self.assertEqual(output_string, replace_digits(input_string))

        #Test a string with digit(s) spread out in the input string
        input_string = "Core courses: CIT-5910, CIT-5920, CIT-5930, CIT-5940, CIT-5950, CIT-5960"
        output_string = "Core courses: CIT-----, CIT-----, CIT-----, CIT-----, CIT-----, CIT-----"
        self.assertEqual(output_string, replace_digits(input_string))

    def test_string_is_palindrome(self):
        #Test a short palindrome with an apostrophe
        input_string = "Madam, in Eden, I\'m Adam."
        self.assertTrue(is_palindrome(input_string))

        #Test a short palindrome with a punctuation
        input_string = "Was it a car or a cat I saw?"
        self.assertTrue(is_palindrome(input_string))

        #Test a long palindrome with punctuations
        input_string = "Are we not pure? \"No, sir!\" Panama\'s moody Noriega brags. \"It is garbage!\" Irony dooms a man—a prisoner up to new era."
        self.assertTrue(is_palindrome(input_string))

        #Test a non-palindrome string
        input_string = "Was it a car or a cat I saw? Adding text"
        self.assertFalse(is_palindrome(input_string))

        #Test a non-palindrome string with an apostrophe
        input_string = "Adding text Madam, in Eden, I\'m Adam."
        self.assertFalse(is_palindrome(input_string))

    def test_replace_element_in_list(self):
        # Test if the target element is not in the given list
        given_list = [1, 6, 3, 4, 5]
        target_element = 10
        new_element = 2
        self.assertRaises(RuntimeError, replace_element_in_list, given_list, target_element, new_element)
        self.assertNotIn(new_element, given_list, "given_list should not be modified if it raises a RuntimeError")

        # Test if the given list is empty
        given_list = []
        target_element = 10
        new_element = 5
        self.assertRaises(RuntimeError, replace_element_in_list, given_list, target_element, new_element)
        self.assertNotIn(new_element, given_list, "given_list should not be modified if it raises a RuntimeError")

        # Test that the target element is in the given list
        given_list = [1, 6, 3, 4, 5]
        target_element = 6
        new_element = 2
        replace_element_in_list(given_list, target_element, new_element)
        self.assertListEqual([1, 2, 3, 4, 5], given_list, "given_list should be updated with new element")
        self.assertNotIn(target_element, given_list, "target_element should be replaced with new_element")
        self.assertIn(new_element, given_list,  "target_element should be replaced with new_element")

        # Test that the target element is in the given list
        given_list = [3, "little", "pigs"]
        target_element = "pigs"
        new_element = "monkeys"
        replace_element_in_list(given_list, target_element, new_element)
        self.assertListEqual([3, "little", "monkeys"], given_list, "given list should be updated with new element")
        self.assertNotIn(target_element, given_list, "target_element should be replaced with new_element")
        self.assertIn(new_element, given_list, "target_element should be replaced with new_element")


    def test_list_calculate_average(self):
        # Test if no elements in the given_list could be cast to float
        given_list = ['a', 'e', 'i', 'o', 'u']
        # Calling the calculate_average would raise a ZeroDivisionError
        self.assertRaises(ZeroDivisionError, calculate_average, given_list)
        # The given_list should be modified
        self.assertNotEqual(['a', 'e', 'i', 'o', 'u'], given_list, "The given_list should remove non numeric elements")
        # Any string element should not be in the given list
        self.assertNotIn('a', given_list, "The given_list should remove non numeric elements")
        # The given_list should be empty
        self.assertTrue(len(given_list) == 0, "The given_list should remove non numeric elements")

        # Test if all elements in given_list could be cast to float
        given_list = [1.23, 4.5, 6.78, "9"]
        # Return value should be the average. Use AlmostEqual to check value up to specified decimal places.
        self.assertAlmostEqual(5.38, calculate_average(given_list), 2, "Average calculation is incorrect up to 2 decimal places")
        # The given_list should now reflect "9" as a float data type
        self.assertListEqual([1.23, 4.5, 6.78, 9.0], given_list, "The given_list should cast all numeric elements to float")

        # Test for mixed data types
        given_list = [1.23, "4.5", 6.78, "9", "string"]
        # Return value should be the average. Use AlmostEqual to check value up to specified decimal places.
        self.assertAlmostEqual(5.38, calculate_average(given_list), 2, "Average calculation is incorrect up to 2 decimal places")
        # The given_list should now reflect "4.5" and "9" as a float data type
        self.assertListEqual([1.23, 4.5, 6.78, 9.0], given_list, "The given_list should cast all numeric elements to float and remove non numeric elements")
        # The text "string" should be removed from the given_list
        self.assertNotIn("string", given_list, "The given_list should cast all numeric elements to float and remove non numeric elements")

    def test_list_remove_duplicate_elements(self):
        #Test a list with no duplicate elements
        given_list = [1, 2, 3, "3"]
        correct_list = [1, 2, 3, "3"]
        #The list should be the same as there are no duplicate values
        self.assertListEqual(correct_list, given_list)

        #Test a list with duplicate elements
        given_list = [1, 2, 2, 3, 4, "4"]
        #Modify the list by calling the function
        remove_duplicate_elements(given_list)
        correct_list = [1, 2, 3, 4, "4"]
        #The lists should have the same elements but order doesn't matter
        self.assertCountEqual(correct_list, given_list)


    def test_list_common_elements(self):
        #Test 2 lists with no common elements
        given_list_1 = ["1", "2", "2", "4"]
        given_list_2 = [1, 2, 2, 4]
        #Obtain the list of common elements from calling the function
        answer_list = common_elements(given_list_1, given_list_2)
        list_of_common_elements = []
        #Ensure the answer is an empty list since there are no elements that match
        self.assertListEqual(list_of_common_elements, answer_list)


        #Test 2 lists with common elements
        given_list_1 = ["1", "2", "2", "4"]
        given_list_2 = [1, "2", 2, 4]
        #Obtain the list of common elements from calling the function
        answer_list = common_elements(given_list_1, given_list_2)
        list_of_common_elements = ["2"]
        #Ensure the answer contains the same elements as expected, with order not mattering
        self.assertCountEqual(list_of_common_elements, answer_list)


if __name__ == '__main__':
    unittest.main()
