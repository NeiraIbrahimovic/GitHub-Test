# String Functions
def concatenate(element_1, element_2):
    """
    Converts each element to a string and returns a concatenated string of the elements
    @param element_1: First element
    @param element_2: Second element
    @return: Concatenated string of element_1 and element_2
    """
    # Cast to string
    element_1 = str(element_1)
    element_2 = str(element_2)
    # Return concatenated elements
    return element_1 + element_2


def remove_vowels(input_string):
    """
    Removes the vowels from the string without changing the string casing and spacing.
    Assume that the input will always be a string with at least one consonant letter.
    @param input_string: The given string
    @return: Output string without the vowels
    """
    #Create list of vowels
    vowels = "aeiouAEIOU"

    #Replace each vowel with an empty string
    for vowel in vowels:
        input_string = input_string.replace(vowel, '')

    return input_string


def replace_digits(input_string):
    """
    Replaces the digit characters in the input_string with a '-' character without changing the string casing and spacing.
    Assume that the input will always be a string with a non-digit character.
    @param input_string: The input string
    @return: The modified string
    """
    #Create list of digits
    digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    #Replace each digit with '-' character
    for digit in digits:
        input_string = input_string.replace(digit, '-')

    return input_string


def is_palindrome(input_string):
    """
    Determines if a string is a palindrome (case-insensitive). Ignore non-alphanumeric characters.
    Example palindromes that should return true:
        "Madam, in Eden, I\'m Adam."
        "Was it a car or a cat I saw?"
        "Are we not pure? \"No, sir!\" Panama\'s moody Noriega brags. \"It is garbage!\" Irony dooms a man—a prisoner up to new era."
    @param input_string: The string to be evaluated.
    @return: A boolean value if a string is a palindrome or not
    """
    #Initialize a new string to hold only alphanumeric characters
    new_string = []

    #Turn all characters in input_string to lowercase
    input_string = input_string.lower()

    #Add characters to new list only if they are alphanumeric
    for char in input_string:
        if char.isalpha() or char.isdigit():
            new_string.append(char)

    #Return true if new_string is equal to itself in reverse
    if new_string == new_string[::-1]:
        return True
    else:
        return False


# List Functions
def replace_element_in_list(given_list, target_element, new_element):
    """
    From a given list, replace the target element with the new element.
    If the target element does not exist in the given list or the given list is empty, raise a RuntimeError
    Assume that the elements in the given_list are unique and there are no duplicates.
    The elements in the list could be of mixed data types.
    @param given_list: The list to be updated
    @param target_element: The target element to replace from the given list
    @param new_element: The new element to add in the given list
    @return: Does not return anything. List is updated by reference.
    """
    if target_element not in given_list or len(given_list) == 0:
        raise RuntimeError("Target element not in list or list is empty.")
    else:
        # Get the index of the target element
        index = given_list.index(target_element)
        # Replace the target index with the new element
        given_list[index] = new_element


def calculate_average(given_list):
    """
    Modify the given_list by casting each element to a float data type. If the element could not be cast to float,
    remove that element from the given_list. The list is to be updated by reference.
    Examples:
    given_list = ['a', 'e', 'i', 'o', 'u']            ==>    given_list = []
    given_list = [1.23, 4.5, 6.78, "9"]               ==>    given_list = [1.23, 4.5, 6.78, 9.0]
    given_list = [1.23, "4.5", 6.78, "9", "string"]   ==>    given_list = [1.23, 4.5, 6.78, 9.0]
    @param given_list: The given list
    @return: The average as a float of all the elements. If the list becomes empty after filtering out non-numeric
    elements, raise a ZeroDivisionError
    """
    #Remove elements that cannot be converted to a float from the original list
    for element in given_list[:]: #copy of list for safe iteration
        #Try to cast the element to a float and append to new list
        try:
            float(element)
        #Remove the element from the original list if the element cannot be cast to a float
        except:
            given_list.remove(element)

    #Convert every element in the modified list to a float:
    for i in range(len(given_list)):
        given_list[i] = float(given_list[i])

    #Raise a ZeroDivisionError if list becomes empty after filtering out non-numeric elements
    if len(given_list) == 0:
        raise ZeroDivisionError("The list is empty after filtering out non-numeric elements.")

    # Initialize a sum variable
    sum = 0

    #Add all elements in the list, converting each one to a float
    for element in given_list:
        sum += element

    #Return the average
    return sum/(len(given_list))


def remove_duplicate_elements(given_list):
    """
    Modify the given list to remove duplicate elements. Duplicate elements have the same data type and the same value.
    The ordering of elements does not matter.
    Assume that the given_list will at least have one element.
    @param given_list: The list to be updated.
    @return: Does not return anything. List is updated by reference.
    """

    #Initialize a new list to store list values
    list_values = []

    #For every element in the copy of list, add it to the new list of unique values if it's not already there
    for element in given_list[:]:
        if element not in list_values:
            list_values.append(element)
        #If the element is already in the list of values, remove it from the original list, as it is a duplicate
        else:
            given_list.remove(element)


def common_elements(given_list_1, given_list_2):
    """
    From 2 given lists, return a list of common elements between given_list_1 and given_list_2.
    Assume that the given lists will at least have one element.
    The ordering of common elements does not matter.
    @param given_list_1: First list
    @param given_list_2: Second list
    @return: List of the common elements
    """

    #Initalize a list of common elements
    list_of_common_elements = []

    #For every element in the first list, check if the element exists in the second list and wasn't already appended to the list of common elements
    for element in given_list_1:
        if element in given_list_2 and element not in list_of_common_elements:
            #If so, append to the list of common elements
            list_of_common_elements.append(element)

    return list_of_common_elements

