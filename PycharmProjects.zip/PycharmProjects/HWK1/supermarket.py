'''Name: Neira Ibrahimovic
Penn ID: neirai01 (PennID number not assigned yet, this is my PennKey)
I worked independently. I went to TA OH to get help with errors that came up with my function.
I searched on Google to get help with how to define global variables.
'''

# import the random module
# use "winnings = random.randint(2, 10)" to generate a random int from 2 - 10 and store in a variable "winnings"

import random

# unit price of a lottery ticket
constant_lottery_unit_price = 2

# unit price of an apple
constant_apple_unit_price = .99

# unit price of a can of beans
constant_canned_beans_unit_price = 1.58

# unit price of a soda
constant_soda_unit_price = 1.23

# the user has initial $5 for shopping
money = 5

# the user has an initial cost of $0
cost = 0

# the user has initial $0 of winnings
winnings = 0

# the amounts of lottery tickets, apples, cans of beans, and sodas the user has purchased
lottery_amount, apple_amount, canned_beans_amount, soda_amount = 0, 0, 0, 0

# print welcome message and list of prices
print("Welcome to the supermarket! Please see our prices below:")
print("- Lottery tickets cost $2 each")
print("- Apples cost $0.99 each")
print("- Canned Beans cost $1.58 each")
print("- Sodas cost $1.23 each")

# tell the user how much money they have available and ask if they want to purchase a lottery ticket
user_answer = input("\nYou have $" + str(money) + " available to spend. First, would you like to purchase a lottery ticket for the chance of winning $2-$10? (y/n) ")

# if the user inputs “y” or “Y”, process a lottery ticket purchase
if user_answer == "y" or user_answer == "Y":
    lottery_amount += 1 # increase the amount of lottery tickets by 1
    money -= constant_lottery_unit_price # deduct the $2 the user spent on the lottery ticket

    if random.randint(0, 2) == 0: # user has 1/3 probability of winning
        winnings = random.randint(2, 10) # generate a random int from 2 – 10 and store it in the variable "winnings".
        money += winnings # increase the money by the amount won
        print("Congratulations! You won $" + str(winnings) + "!")

    else:
        print("Unfortunately, you did not win the lottery ticket.") # user has 2/3 probability of losing

# if the user inputs anything else, print a message saying that no lottery tickets were purchased and move on to the next item.
else:
    print("No lottery tickets were purchased.")

# define a function for redundant processes
def item_purchase(item):
    '''This function asks the user if they want to purchase the item and how much they want to buy. It then calculates the cost and checks if the user has enough money.'''
    # define global variables so they can be accessed within the function
    global constant_apple_unit_price
    global constant_canned_beans_unit_price
    global constant_soda_unit_price
    global money
    global cost
    global apple_amount
    global canned_beans_amount
    global soda_amount

    # before calling the function, we ask the user if they would like to purchase the item.
    # answer is stored in "user_answer" variable.
    if user_answer == "y" or user_answer == "Y":
        item_quantity = input("How many do you want to buy? ")
        try:
            item_quantity = int(item_quantity) # make sure user inputted an integer

            # calculate the cost based on the item user purchased
            if item == "apple":
                cost = item_quantity * constant_apple_unit_price
            if item == "canned bean":
                cost = item_quantity * constant_canned_beans_unit_price
            if item == "soda can":
                cost = item_quantity * constant_soda_unit_price

            # print a message stating how many items the user wants to buy and how much it costs
            print("The user wants to buy " + str(item_quantity) + " " + item + "(s). This will cost $" + str(round(cost, 2)) + ".")

            # print a message if user doesn't have enough money
            if cost > money:
                print("Not enough money. No " + item + "s were selected.")
            # otherwise, print that the user has enough money to purchase the items
            else:
                print("The user has enough money. " + str(item_quantity) + " " + item + "(s) purchased.")
                # decrease the money the user has left by subtracting the cost
                money -= cost
                # increase the item amount
                if item == "apple":
                    apple_amount += 1
                if item == "canned bean":
                    canned_beans_amount += 1
                if item == "soda can":
                    soda_amount += 1
        # if user doesn't input an integer, print a message to inform them and move on to next item
        except:
            print("Only integers are accepted. No " + item + "s were selected.")

    # if user does not answer "y" or "Y", print a message and move on to next item
    else: print("No ", item, "(s) were purchased.", sep="")

# ask user if they want to purchase apples
user_answer = input("\nYou have $" + str(round(money, 2)) + " left. Would you like to purchase apples for $0.99? (y/n) ")
item_purchase("apple")

# ask user if they want to purchase canned beans
user_answer = input("\nYou have $" + str(round(money, 2)) + " left. Would you like to purchase canned beans for $1.58? (y/n) ")
item_purchase("canned bean")

# ask user if they want to purchase soda cans
user_answer = input("\nYou have $" + str(round(money, 2)) + " left. Would you like to purchase soda cans for $1.23? (y/n) ")
item_purchase("soda can")

# print how much money the user has left and the total amount of everything purchased
print("\nThank you for shopping with us! You have $" + str(round(money, 2)) + " left.")
print("Number of lottery ticket(s) purchased:", str(lottery_amount))
print("Amount of lottery winnings: $" + str(winnings))
print("Number of apple(s) purchased:", str(apple_amount))
print("Number of can(s) of beans purchased:", str(canned_beans_amount))
print("Number of soda(s) purchased:", str(soda_amount))
print("Good bye!")






