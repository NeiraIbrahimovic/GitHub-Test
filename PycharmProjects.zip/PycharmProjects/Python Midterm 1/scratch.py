from ExpensesLoader import *
from ExpensesManager import *

# to store dictionary of expenses
expenses = {}

# create instance of ExpensesLoader class
expenses_loader = ExpensesLoader()

# call import_expenses method in ExpensesLoader class
# to import expense files and store in dictionary
expenses_loader.import_expenses(expenses, 'expenses.txt')
expenses_loader.import_expenses(expenses, 'expenses_2.txt')

# Initialize a list to hold the tuples
list_of_tuples = []

# for every Expense object in the dictionary, create a tuple containing the expense type and amount
for value in expenses.values():
    tuple = (value.expense_type, value.amount)
    # Append the tuple the the list of tuples
    list_of_tuples.append(tuple)
print(expenses)
print(list_of_tuples)

list_of_tuples.sort()
print(list_of_tuples)

list_of_tuples.sort(key = lambda x: x[1], reverse = True)
print(list_of_tuples)