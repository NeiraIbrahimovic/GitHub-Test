from make_website import generate_intro_section

intro = generate_intro_section("Neira Ibrahimovic", "neira@seas.upenn.edu")
print(intro)
