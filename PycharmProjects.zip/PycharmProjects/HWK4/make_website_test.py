import unittest

from make_website import *

class MakeWebsite_Test(unittest.TestCase):

    def test_read_file(self):
        list_of_lines = ['I.M. Student\n', 'Courses :- Programming Languages and Techniques, Biomedical image analysis, Software Engineering\n', 'Projects\n', 'CancerDetector.com, New Jersey, USA - Project manager, codified the assessment and mapped it to the CancerDetector ontology. Member of the UI design team, designed the portfolio builder UI and category search pages UI. Reviewed existing rank order and developed new search rank order approach.\n', 'Biomedical Imaging - Developed a semi-automatic image mosaic program based on SIFT algorithm (using Matlab)\n', '------------------------------\n', 'tonyl@seas.upenn.edu\n']
        # test storing the input file as a list of lines
        self.assertListEqual(list_of_lines, read_file('resume.txt'), 'The input file must be stored as a list of lines.')

    def test_get_name(self):

        # Test cases
        # test getting name from the list of lines
        list_of_lines_regular_name = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neirai01@seas.upenn.edu\n']
        self.assertEqual("Neira Ibrahimovic", get_name(list_of_lines_regular_name), 'The name must be retrieved from the list of lines.')

        # Edge cases
        # test getting name with whitespaces from list of lines (removes whitespaces)
        list_of_lines_whitespaces_name = ['  Neira Ibrahimovic\n   ', 'Courses :- Python, Java\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neirai01@seas.upenn.edu\n']
        self.assertEqual("Neira Ibrahimovic", get_name(list_of_lines_whitespaces_name), 'Leading and trailing whitespace should be removed from the name.')

        # test getting name which doesn't start with uppercase letter (invalid)
        list_of_lines_lowercase_first_name = ['neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neirai01@seas.upenn.edu\n']
        self.assertEqual("Invalid Name", get_name(list_of_lines_lowercase_first_name), 'A name that starts with a lowercase letter should return \'Invalid Name\'.')

        # test getting name which has lowercase last name (valid)
        list_of_lines_lowercase_last_name = ['Neira ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                        'Project 1 description\n', 'Project 2 description\n',
                                        '------------------------------\n', 'neirai01@seas.upenn.edu\n']
        self.assertEqual("Neira ibrahimovic", get_name(list_of_lines_lowercase_last_name), 'A last name that starts with a lowercase letter should be considered valid and the name should be returned as is.')

    def test_get_email_address(self):
        # Test Case
        # test getting the email if the email address is valid
        list_of_lines_valid_email = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neira@seas.upenn.edu\n']
        self.assertEqual("neira@seas.upenn.edu", get_email_address(list_of_lines_valid_email), 'The email address should be returned from the list of lines.')

        # Edge Cases
        # test getting the email if the last four character are not '.edu' or '.com' (should return empty string)
        list_of_lines_invalid_ending_email = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                     'Project 1 description\n', 'Project 2 description\n',
                                     '------------------------------\n', 'neira@seas.upenn.net\n']
        self.assertEqual("", get_email_address(list_of_lines_invalid_ending_email),
                         'The email address should be represented as an empty string if the last four character are not \'.edu\' or \'.com\'.')

        # test getting the email if there is an uppercase English character after the '@' (should return empty string)
        list_of_lines_uppercase_email = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                     'Project 1 description\n', 'Project 2 description\n',
                                     '------------------------------\n', 'neira@Seas.upenn.edu\n']
        self.assertEqual("", get_email_address(list_of_lines_uppercase_email),
                         'The email address should be represented as an empty string if the email contains an uppercase English character after the \'@\'.')

        # test getting the email if there are digits or numbers in the email address (should return empty string)
        list_of_lines_digits_email = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                    'Project 1 description\n', 'Project 2 description\n',
                                    '------------------------------\n', 'neira01@seas.upenn.edu\n']
        self.assertEqual("", get_email_address(list_of_lines_digits_email),
                     'The email address should be represented as an empty string if there are digits or numbers in the email.')

        # test getting the email if there is whitespace surrounding the email
        list_of_lines_whitespace_email = ['Neira Ibrahimovic\n', 'Courses :- Python, Java\n', 'Projects\n',
                                    'Project 1 description\n', 'Project 2 description\n',
                                    '------------------------------\n', '   neira@seas.upenn.edu\n   ']
        self.assertEqual("neira@seas.upenn.edu", get_email_address(list_of_lines_whitespace_email),
                     'Leading and trailing whitespace should be removed from the email address before returning it.')

    def test_get_list_of_courses(self):
        #Test Cases
        # test getting the list of courses
        list_of_lines_regular_courses = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Python', 'Java', 'Ceramics'], get_list_of_courses(list_of_lines_regular_courses),
                             'The courses should be returned as a list.')

        #Edge Cases
        # test getting the list of courses if there is whitespace around "Courses" and punctuation
        list_of_lines_whitespace_courses = ['Neira Ibrahimovic\n', '  Courses  :-  Python, Java, Ceramics\n  ', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Python', 'Java', 'Ceramics'], get_list_of_courses(list_of_lines_whitespace_courses),
                            'Leading and trailing whitespace should be removed before returning the list of courses.')

        # test getting the list of courses if individual courses have surrounding whitespace
        list_of_lines_whitespace_each_course = ['Neira Ibrahimovic\n', 'Courses :-   Python  ,   Java \n ,   Ceramics\n  ', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Python', 'Java', 'Ceramics'], get_list_of_courses(list_of_lines_whitespace_each_course),
                            'Leading and trailing whitespace should be removed before returning the list of courses.')

        # test getting the list of courses if "Courses" is followed by abnormal punctuation
        list_of_lines_weird_punc_courses = ['Neira Ibrahimovic\n', 'Courses :-!$%^&* Python, Java, Ceramics\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '------------------------------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Python', 'Java', 'Ceramics'], get_list_of_courses(list_of_lines_weird_punc_courses),
                            'The list of courses should be returned even if "Courses" is followed by abnormal punctuation.')

    def test_get_list_of_projects(self):
        #Test Case
        # test getting the list of projects with subsequent line of exactly 10 minus signs
        list_of_lines_projects = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '----------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Project 1 description', 'Project 2 description'], get_list_of_projects(list_of_lines_projects),
                             'Every project in the projects line should be returned as a list until you hit a line that contains at least ten minus signs put together.')

        #Edge Cases
        # test getting list of projects with subsequent line containing more than 10 minus signs
        list_of_lines_projects_more_minus_signs = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n', 'Projects\n',
                                      'Project 1 description\n', 'Project 2 description\n',
                                      '-------------------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Project 1 description', 'Project 2 description'], get_list_of_projects(list_of_lines_projects_more_minus_signs),
                             'Every project in the projects line should be returned as a list until you hit a line that contains at least ten minus signs put together. More than ten minus signs also indicates the end of the Projects.')

        # test getting list of projects with subsequent line containing less than 10 minus signs
        list_of_lines_projects_less_minus_signs = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n',
                                                   'Projects\n',
                                                   'Project 1 description\n', 'Project 2 description\n',
                                                   '---------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Project 1 description', 'Project 2 description', '---------', 'neira@seas.upenn.edu'],
                             get_list_of_projects(list_of_lines_projects_less_minus_signs),
                             'Every project in the projects line should be returned as a list until you hit a line that contains at least ten minus signs put together. Less than ten minus signs do not indicate the end of the Projects list.')

        # test getting list of projects if blank lines exist between projects (blank lines should be ignored)
        list_of_lines_projects_blank_lines = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n',
                                                   'Projects\n',
                                                   'Project 1 description\n', '', 'Project 2 description\n',
                                                   '----------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Project 1 description', 'Project 2 description'],
                             get_list_of_projects(list_of_lines_projects_blank_lines),
                              'If a blank line exists between project descriptions, that line should be ignored when returning the list of projects.')

        # test getting list of projects if project has leading or trailing whitespace
        list_of_lines_projects_whitespace = ['Neira Ibrahimovic\n', 'Courses :- Python, Java, Ceramics\n',
                                                   'Projects\n', '  Project 1 description\n  ', '  Project 2 description\n  ',
                                                   '----------\n', 'neira@seas.upenn.edu\n']
        self.assertListEqual(['Project 1 description', 'Project 2 description'],
                             get_list_of_projects(list_of_lines_projects_whitespace),
                              'Leading and trailing whitespace should be removed when returning the list of projects.')

    def test_create_email_link(self):

        # test email with @ sign
        self.assertEqual(
            '<a href="mailto:lbrandon@wharton.upenn.edu">lbrandon[aT]wharton.upenn.edu</a>',
            create_email_link('lbrandon@wharton.upenn.edu'), 'An email link should be created with the given email address.'
        )

        # test email with @ sign
        self.assertEqual(
            '<a href="mailto:krakowsky@outlook.com">krakowsky[aT]outlook.com</a>',
            create_email_link('krakowsky@outlook.com'), 'An email link should be created with the given email address.'
        )

        # test email without @ sign
        self.assertEqual(
            '<a href="mailto:lbrandon.at.seas.upenn.edu">lbrandon.at.seas.upenn.edu</a>',
            create_email_link('lbrandon.at.seas.upenn.edu'),
            'An email link should be created with the given email address. If the given email address does not contain \'@\', the email address should be used as is.'
        )

    def test_surround_block(self):
        # test text with surrounding h1 tags
        self.assertEqual("<h1>Eagles</h1>", surround_block('h1', 'Eagles'),
                         'The given text should be surrounded by the given tags using correct HTML formatting.')

        # test text with surrounding h2 tags
        self.assertEqual("<h2>Red Sox</h2>", surround_block('h2', 'Red Sox'),
                         'The given text should be surrounded by the given tags using correct HTML formatting.')

        # test text with surrounding p tags
        self.assertEqual('<p>Lorem ipsum dolor sit amet, consectetur ' +
                         'adipiscing elit. Sed ac felis sit amet ante porta ' +
                         'hendrerit at at urna.</p>',
                         surround_block('p', 'Lorem ipsum dolor sit amet, consectetur ' +
                                        'adipiscing elit. Sed ac felis sit amet ante porta ' +
                                        'hendrerit at at urna.'),
                         'The given text should be surrounded by the given tags using correct HTML formatting.')

    def test_read_resume_template(self):
        #Test Case
        # test reading the resume template file and storing as list of lines
        list_of_lines = ['<PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"\n', '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n', '\n', '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n', '\n', '<head>\n', '     <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>\n', '\n', '     <title>My Resume</title>\n', '\n', '     <style type="text/css">\n', '        * { margin: 0; padding: 0; }\n', '        body { font: 16px Helvetica, Sans-Serif; line-height: 24px; }\n', '        .clear { clear: both; }\n', '        #page-wrap { width: 800px; margin: 40px auto 60px; }\n', '        #pic { float: right; margin: -30px 0 0 0; }\n', '        h1 { margin: 0 0 16px 0; padding: 0 0 16px 0; font-size: 42px; font-weight: bold; letter-spacing: -2px; border-bottom: 1px solid #999; }\n', '        h2 { font-size: 20px; margin: 0 0 6px 0; position: relative; }\n', '        h2 span { position: absolute; bottom: 0; right: 0; font-style: italic; font-family: Georgia, Serif; font-size: 16px; color: #999; font-weight: normal; }\n', '        p { margin: 0 0 16px 0; }\n', '        a { color: #999; text-decoration: none; border-bottom: 1px dotted #999; }\n', '        a:hover { border-bottom-style: solid; color: black; }\n', '        ul { margin: 0 0 32px 17px; }\n', '        #objective { width: 500px; float: left; }\n', '        #objective p { font-family: Georgia, Serif; font-style: italic; color: #666; }\n', '        dt { font-style: italic; font-weight: bold; font-size: 18px; text-align: right; padding: 0 26px 0 0; width: 150px; float: left; height: 100px; border-right: 1px solid #999;  }\n', '        dd { width: 600px; float: right; }\n', '        dd.clear { float: none; margin: 0; height: 15px; }\n', '     </style>\n', '</head>\n', '<body>\n', '</body>\n', '</html>\n']
        self.assertListEqual(list_of_lines, read_resume_template('resume_template.html'), 'The input file must be stored as a list of lines.')

    def test_remove_last_two_lines(self):
        # Test Case
        # test removing the last two lines from the list of lines
        list_of_lines = ['line1', 'line2', 'line3', 'line4']
        self.assertListEqual(['line1', 'line2'], remove_last_two_lines(list_of_lines), 'The last two lines should be removed from the list.')

    def test_generate_intro_section(self):
        # Test Case
        # test generating the intro section given a name and email
        name = "Neira Ibrahimovic"
        email = "neira@seas.upenn.edu"
        correct_intro_section = "\n\n<div>\n<h1>Neira Ibrahimovic</h1>\n<p>Email: <a href=\"mailto:neira@seas.upenn.edu\">neira[aT]seas.upenn.edu</a></p>\n</div>\n"
        self.assertEqual(correct_intro_section, generate_intro_section(name, email), "The intro section is not accurately generated.")

       # test generating the intro section given an invalid name and invalid email
        invalid_name = "Invalid Name"
        invalid_email = ""
        correct_intro_section = "\n\n<div>\n<h1>Invalid Name</h1>\n<p>Email: <a href=\"mailto:\"></a></p>\n</div>\n"
        self.assertEqual(correct_intro_section, generate_intro_section(invalid_name, invalid_email), "The intro section is not accurately generated.")


    def test_generate_projects_section(self):
        # Test Case
        # test generating the project section given the list of projects
        list_of_projects = ["Project 1 description", "Project 2 description"]
        correct_projects_section = "\n<div>\n<h2>Projects</h2>\n<ul>\n<li>Project 1 description</li>\n<li>Project 2 description</li>\n</ul>\n</div>\n"
        self.assertEqual(correct_projects_section, generate_projects_section(list_of_projects), "The projects section is not accurately generated.")

    def test_generate_courses_section(self):
        # Test Case
        # test generating the courses section given the list of courses
        list_of_courses = ["Python", "Java"]
        correct_courses_section = "\n<div>\n<h3>Courses</h3>\n<span>Python, Java</span>\n</div>\n"
        self.assertEqual(correct_courses_section, generate_courses_section(list_of_courses), "The courses section is not accurately generated.")

if __name__ == '__main__':
    unittest.main()