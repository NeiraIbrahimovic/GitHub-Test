# Student Name in Canvas: Neira Ibrahimovic
# PennKey: neirai01 (don't have PennID number because I am remote)
# Did you do this homework on your own (yes / no): yes
# Resources used outside course materials:
# I used class resources such as lecture slides and videos

def read_file(txt_input_file):
    '''
    Reads the given file and stores it in memory as a list of lines.
    Parameter: text_input_file which is the resume text file
    Returns: List of lines in the resume text file
    '''

    #Open the file
    with open(txt_input_file) as resume_file:
        #Turn the file into a list of lines
        list_of_lines = resume_file.readlines()

    return list_of_lines

def get_name(list_of_lines):
    '''
    Extracts the first line of the list of lines to represent the name value.
    Removes leading or trailing whitespaces.
    If the first character in the name string is not an uppercase letter, use 'Invalid Name' as the user's name.
    Parameter: List of lines in the resume text file
    Returns: String representing the name
    '''

    #Extract the first value in the list of lines, remove leading and trailing whitespaces, and assign to name variable
    name = list_of_lines[0].strip()

    #If the first character in the name is lowercase, return "Invalid Name"
    if name[0].islower():
        return "Invalid Name"
    #Otherwise, return the name
    else:
        return name


def get_email_address(list_of_lines):
    '''
    Detects and returns the email address by looking for the line in the given list of lines with the '@' character.
    Removes leading or trailing whitespaces from the email address.
    For an email to be valid:
        - The last four characters of the email need to be either '.com' or '.edu'.
        - The email contains a lowercase English character after the '@'.
        - There should be no digits or numbers in the email address.
    Parameter: List of lines in the resume text file
    Returns: String representing the email address. If an email string is invalid, return empty string.
    '''

    #Initialize email variable as an empty strings
    email = ''
    #Initialize the variable to hold the index of the '@' symbol
    index_of_symbol = None

    #Iterate through every character in every line until you detect the '@' symbol
    for line in list_of_lines:
        for char in line:
            #Once you detect the '@' symbol, set the line to the email variable with leading and trailing whitespace removed
            if char == '@':
                index_of_symbol = line.find(char)
                email = line.strip()

    #Check that the last 4 characters of the email are either '.com' or '.edu'
    #If not, return an empty string
    if email[-4::1] != ".com" and email[-4::1] != ".edu":
        #If the email does not end with '.com' or '.edu', return an empty string
        return ''

    #Check that the email contain a lowercase English character after the '@' symbol
    if email[index_of_symbol + 1].isupper():
        return ''

    #Check that there are no digits or numbers in the email address
    for char in email:
        #If there is a digit, return an empty string
        if char.isdigit():
            return ''

    #Return the email if it is valid
    return email

def get_list_of_courses(list_of_lines):
    '''
    Detects and returns the courses as a list by looking for the word "Courses" in the list and then extracting the line that contains that word.
    Ignores any punctuation after the word "Courses" and before the first actual course.
    Removes leading or trailing whitespace.
    Parameter: List of lines in the resume text file
    Returns: List of courses
    '''

    #Initalize variable to hold the string of courses
    courses_str = ''

    #Initialize a list of courses
    list_of_courses = []

    #Initalize a variable to hold the index of the first letter after the leading punctuation
    index_of_first_letter = None

    #Initialize variable to hold string of ascii letters:
    ascii_letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

    #Iterate through every line until you detect the 'Courses' string
    for line in list_of_lines:
        #Check if "Courses" is in the line
        if "Courses" in line:
            #If so, split the line on the word "Courses" and set the second element to the courses_str variable after removing leading and trailing whitespace
            #This will return a string of all characters in the line that come after "Courses"
            courses_str = line.split("Courses")[1].strip()

    #Find the first letter after the leading punctuation and store the index in a variable
    for char in courses_str:
        if char in ascii_letters:
            index_of_first_letter = courses_str.find(char)
            #Break out of the for loop once you find the first letter after the punctuation
            break

    #Create a new string variable to hold the courses with the leading punctuation removed
    #To do so, splice the string to only include characters after the index of the first letter
    new_courses_str = courses_str[index_of_first_letter:]

    #Split the string with the comma delimiter to create a list of courses
    #Remove the leading and trailing whitespace for every course in the new list
    list_of_courses = [course.strip() for course in new_courses_str.split(',')]

    #Return the list of courses
    return list_of_courses

def get_list_of_projects(list_of_lines):
    '''
    Detects and returns the projects as a list by looking for the word "Projects" in the list.
    Each subsequent line is a project, until you hit a line that contains '----------', which is at least ten minus signs put together.
    Ignores blank lines between project descriptions.
    Removes leading and trailing whitespace from each project.
    Parameter: List of lines in the resume text file
    Returns: List of projects
    '''

    #Initialize a variable to store the index of the "Projects" line
    start_of_projects_index = None

    #Initialize a variable to store the index of the "----------" line
    end_of_projects_index = None

    #Iterate through every line until you detect the 'Projects' string
    for line in list_of_lines:
        #Check if "Projects" is in the line. If so, store the index of the line.
        if "Projects" in line:
            start_of_projects_index = list_of_lines.index(line)
        #Check if "----------" is in the line. If so, store the index of the line.
        if "----------" in line:
            end_of_projects_index = list_of_lines.index(line)

    #Slice the list of lines to only include the lines after the "Projects" line and up to the "----------" line
    list_of_projects = list_of_lines[start_of_projects_index + 1:end_of_projects_index]

    #Remove leading and trailing whitespace from every line in the list
    list_of_projects = [project.strip() for project in list_of_projects]

    #Remove blank lines between projects
    while '' in list_of_projects:
        list_of_projects.remove('')

    #Return the list of projects
    return list_of_projects


def create_email_link(email_address):
    """
    Creates an email link with the given email_address.
    To cut down on spammers harvesting the email address from the webpage,
    displays the email address with [aT] instead of @.

    Example: Given the email address: lbrandon@wharton.upenn.edu
    Generates the email link: <a href="mailto:lbrandon@wharton.upenn.edu">lbrandon[aT]wharton.upenn.edu</a>

    Note: If, for some reason the email address does not contain @,
    use the email address as is and don't replace anything.

    Parameter: email address is a string containing the email address which an email link will be generated from
    Returns: string containing email link displayed in correct format
    """

    #Store email address with '@' replaced with '[aT]' in variable
    new_email_address = email_address.replace('@', '[aT]')

    #Create the email link by concatenating the email addresses with HTML tags
    email_link = "<a href=\"mailto:" + email_address + "\">" + new_email_address + "</a>"

    return email_link


def surround_block(tag, text):
    """
    Surrounds the given text with the given html tag and returns the string.
    Parameters:
        - tag: String containing the HTML tag that should surround the given text (eg 'h1')
        - text: String containing the text that will be surrounded by the tag
    Returns: String containing the given text surrounded by the given HTML tag
    """

    #Concatenate the tag and text with HTML formatting
    string_with_tags = "<" + tag + ">" + text + "</" + tag + ">"

    #Return the text with surrounding HTML tags
    return string_with_tags

def read_resume_template(resume_template_html_file):
    '''
    Opens and reads every line of resume_template.html into program memory.
    Parameter: resume_template_file is the html file containing the resume template with the header and empty body
    Returns: List of lines storing every line in the html resume template file
    '''

    #Open the file
    with open(resume_template_html_file) as resume_template_html_file:
        #Turn the file into a list of lines
        list_of_html_lines = resume_template_html_file.readlines()

    return list_of_html_lines

def remove_last_two_lines(list_of_html_lines):
    '''
    Removes the last two lines from the list of lines generated from the html resume template file.
    Parameter: list_of_html_lines is a list of lines storing every line in the html resume template file
    Returns: list of lines from the html resume template file with the last two lines removed
    '''

    #Slice the list of html lines to include all lines up to the second to last entry
    #This will effectively remove the last two lines
    list_of_html_lines = list_of_html_lines[:-2:1]

    return list_of_html_lines

def generate_intro_section(name, email):
    '''
    Creates intro section including name and header enclosed by correct HTML tags
    Parameters:
        - name: string representing the name of the person on the resume
        - email: string representing the email of the person on the resume
    Returns: string containing intro section enclosed by correct HTML tags
    '''

    #Enclose the name and email with correct tags and store this string in a variable
    #Add "Email:" before the email link
    intro_content = '\n' + surround_block('h1', name) + '\n' + surround_block('p', "Email: " + create_email_link(email)) + '\n'

    #Enclose the name and email with <div></div> tags
    wrapped_content = '\n\n' + surround_block('div', intro_content) + '\n'

    return wrapped_content

def generate_projects_section(list_of_projects):
    '''
    Creates projects section with projects enclosed by correct HTML tags to separate each project into a bullet point list when rendered
    Parameter: list_of_projects is a list containing the projects and project descriptions
    Returns: string containing projects section enclosed by correct HTML tags
    '''

    #Initialize variable to store unordered list content
    unordered_list_of_projects = '\n'

    #Create the content that will be enclosed within the unordered list tags <ul></ul>
    for line in list_of_projects:

        #Enclose each line with the 'li' HTML tag, which will render as a bullet point
        project_bullet_point = surround_block('li', line)

        #Concatenate the project to the list of projects
        unordered_list_of_projects = unordered_list_of_projects + project_bullet_point + '\n'

    # Enclose the projects with correct tags and store this string in a variable
    project_content = '\n' + surround_block('h2', "Projects") + '\n' + surround_block('ul', unordered_list_of_projects) + '\n'

    # Enclose the projects with <div></div> tags
    wrapped_content = '\n' + surround_block('div', project_content) + '\n'

    return wrapped_content

def generate_courses_section(list_of_courses):
    '''
    Creates courses section with courses enclosed by correct HTML tags
    Parameter: list_of_courses is a list containing courses
    Returns: string containing courses section enclosed by correct HTML tags
    '''

    #Join the courses in the list of courses into a single string separated by commas
    string_of_courses = ', '.join(list_of_courses)

    #Enclose the courses with correct tags and store this string in a variable
    course_content = '\n' + surround_block('h3', "Courses") + '\n' + surround_block('span', string_of_courses) + '\n'

    #Enclose the name and email with <div></div> tags
    wrapped_content = '\n' + surround_block('div', course_content) + '\n'

    return wrapped_content


def generate_html(txt_input_file, html_output_file):
    """
    Loads given txt_input_file,
    gets the name, email address, list of projects, and list of courses,
    then writes the info to the given html_output_file.
    Parameters:
        - txt_input_file: the text file storing the resume
        - html_output_file: the html file we will output to
    Returns: None
    """

    #Call function to load given txt_input_file and generate the list of lines from the file
    list_of_lines = read_file(txt_input_file)

    #Call the function to get the name from the resume and store in variable
    name = get_name(list_of_lines)

    #Call the function to get the email address from the resume and store in variable
    email_address = get_email_address(list_of_lines)

    #Call the function to get the list of projects and store in variable
    list_of_projects = get_list_of_projects(list_of_lines)

    #Call the function to get the list of courses and store in variable
    list_of_courses = get_list_of_courses(list_of_lines)

    #Call the function to get the list of html lines from resume_template.html
    list_of_html_lines = read_resume_template('resume_template.html')

    #Call the function to remove the last two lines from the list of lines generated from the resume_template.html file
    list_of_html_lines = remove_last_two_lines(list_of_html_lines)

    #Call the function to make intro section of resume
    intro_section = generate_intro_section(name, email_address)

    #Call the function to make projects section of resume
    projects_section = generate_projects_section(list_of_projects)

    #Call the function to make courses section of resume
    courses_section = generate_courses_section(list_of_courses)

    #Open the resume.html file for appending
    resume_file = open(html_output_file, "a")

    #Append the list of lines generated from the resume_template.html file to a resume.html file
    resume_file.writelines(list_of_html_lines)

    #Append the rest of the content to the resume.html file
    resume_file.write("<div id=\"page-wrap\">" + intro_section + projects_section + courses_section + "\n</div>\n</body>\n</html>")

    #Close the resume.html file
    resume_file.close()

def main():

    # DO NOT REMOVE OR UPDATE THIS CODE
    # generate resume.html file from provided sample resume.txt
    generate_html('resume.txt', 'resume.html')

    # DO NOT REMOVE OR UPDATE THIS CODE.
    # Uncomment each call to the generate_html function when you’re ready
    # to test how your program handles each additional test resume.txt file
    generate_html('TestResumes/resume_bad_name_lowercase/resume.txt', 'TestResumes/resume_bad_name_lowercase/resume.html')
    generate_html('TestResumes/resume_courses_w_whitespace/resume.txt', 'TestResumes/resume_courses_w_whitespace/resume.html')
    generate_html('TestResumes/resume_courses_weird_punc/resume.txt', 'TestResumes/resume_courses_weird_punc/resume.html')
    generate_html('TestResumes/resume_projects_w_whitespace/resume.txt', 'TestResumes/resume_projects_w_whitespace/resume.html')
    generate_html('TestResumes/resume_projects_with_blanks/resume.txt', 'TestResumes/resume_projects_with_blanks/resume.html')
    generate_html('TestResumes/resume_template_email_w_whitespace/resume.txt', 'TestResumes/resume_template_email_w_whitespace/resume.html')
    generate_html('TestResumes/resume_wrong_email/resume.txt', 'TestResumes/resume_wrong_email/resume.html')

    # If you want to test additional resume files, call the generate_html function with the given .txt file
    # and desired name of output .html file

if __name__ == '__main__':
    main()