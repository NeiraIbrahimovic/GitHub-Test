# Students, fill out statement of work header
# Student Name in Canvas: Neira Ibrahimovic
# PennKey: neirai01 (don't have PennID number because I am remote)
# Did you do this homework on your own (yes / no): yes
# Resources used outside course materials:
# I used Python docs to search up functions, Google to search how to use specific functions, and TA Office Hours for help with bugs.

# import statements
from random import randint, shuffle

def print_game_instructions():
    '''
    Prints game instructions.
    Returns: string of game instructions
    '''

    print("Welcome to the WATER TANK game and play against the computer!\n"
          "The first player to fill their tank to a water level between 75-80 wins the game.\n"
          "Every player will have 5 cards at a time.\n"
          "You can use water cards to fill your tank or use the following power cards:\n"
          "\tSOH: steal opponent's half\n"
          "\tDOT: drain opponent's half\n"
          "\tDMT: double my tank\n"
          "In each round, you can choose to use or discard your card.\n"
          "Good luck!\n")

def get_random_player():
    '''
    Chooses a random player to go first
    Returns: string listing which player should go first ("Human Player" or "Computer Player")
    '''

    #Choose a random number between 1 to 2
    random_number = randint(1, 2)

    #Return "Human Player" or "Computer Player" based on the random number
    if random_number == 1:
        return("Human Player")
    else:
        return("Computer Player")


def use_or_discard(question):
    '''
    Prompts the user with the given question on whether they want to use or discard their card and processes the input as so:
        1. Removes leading and trailing whitespaces
        2. If the length of the user input after removing leading and trailing whitespaces is 0, reprompt the user
        3. Turns the user answer into a lowercase string.
        4. If the user input is not valid, reprompt the user.
        5. If the user input is "u", returns "u".
        6. If the user input is "d", returns "d".
    Parameter: question in the form of a string prompting the user whether they want to use or discard the card
    Returns: string based on user's answer (either "u" or "d")
    '''

    #Initializes a string variable to hold the user's answer
    answer = ""

    #Continue this loop while the user enters an empty answer.
    #The first iteration will automatically run because we initialized the string variable answer to be empty.
    while len(answer) == 0:

        #Get user input on question
        answer = input(question)

        #Remove leading and trailing whitespaces
        answer = answer.strip()

        #Turn answer into a lowercase string
        answer = answer.lower()

        #If user enters an empty answer, prompt again
        if len(answer) == 0:
            print("No answer was received. Please enter an answer.")

        #If user enters an answer other than "u" or "d", prompt again
        if answer != "u" and answer != "d":
            print("Not a valid answer. Please enter 'u' to use the card and 'd' to discard the card.")
            #Re-initialize the answer to 0 so the while loop can run again
            answer = ""

    #Return user's answer
    if answer == "u":
        return "u"
    else:
        return "d"

def get_card_to_discard(player_cards):
    '''
    Gets the card the user wants to discard.
    Parameter: the list of the player's cards
    Returns: the card the player wants to discard
    '''

    #Initialize a variable with a dummy card to discard
    card_to_discard = None

    #Continue this loop until the user chooses a valid card in their deck
    while card_to_discard not in player_cards:
        #Ask the user for which card they want to discard
        user_input = input("Which card do you want to discard? ")

        #Try to convert the input to an integer to check if the user inputted a number
        try:
            card_to_discard = int(user_input)
        #Otherwise, accept the input as a string
        except ValueError:
            card_to_discard = user_input

        #If the user chooses a card that they do not have, reprompt the user
        if card_to_discard not in player_cards:
            print("You do not have this card. Please choose a valid card.")
        #Otherwise, return the card the user wants to discard
        else:
            return card_to_discard

def get_user_input(question):
    '''
    Prompts the user with the given question on what play they want to make and processes the input as so:
       1. Removes leading and trailing whitespaces
       2. If the length of the user input after removing leading and trailing whitespaces is 0, reprompt the user.
       3. If the input is a number, casts and returns an integer type.
       4. If the input is a power card, returns the power card as an uppercase string.
       5. If the input is any other string, returns as a lowercase string.
    Parameter: question in the form of a string prompting the user what play they want to make
    Returns: processed input (either an integer, uppercase power card string, or lowercase string)
    '''

    # Initializes a string variable to hold the user's answer
    answer = ""

    #Continue this loop while the user enters an empty answer.
    #The first iteration will automatically run because we initialized the string variable answer to be empty.
    while len(answer) == 0:

        #Get user input on question
        answer = input(question)

        #Remove leading and trailing whitespaces
        answer = answer.strip()

        #Turn answer into a lowercase string
        answer = answer.lower()

        #If user enters an empty answer, prompt again
        if len(answer) == 0:
            print("No answer was received. Please enter an answer.")

    #If the answer is an integer, return that number cast to an integer.
    try:
        return int(answer)
    #If the answer is a power card, return the answer in uppercase
    except ValueError:
        if answer in ("soh", "dot", "dmt"):
            return answer.upper()
        #If the answer is any other string, return the answer in lowercase (answer is already in lowercase from earlier)
        else:
            return answer


def setup_water_cards():
    '''
    Creates a shuffled list of water cards with the following values and quantities:
        - 30 water cards with a value of 1
        - 15 water cards with a value of 5
        - 8 water cards with a value of 10
    Returns: water cards as a list of integers
    '''

    #create a list with the correct values
    water_cards = [1]*30 + [5]*15 + [10]*8

    #shuffle the list
    shuffle(water_cards)

    #return the shuffled list of integers
    return water_cards

def setup_power_cards():
    '''
    Creates a shuffled list of power cards with the following values and quantities:
        - 10 SOH power cards
        - 2 DOT power cards
        - 3 DMT power cards
    Returns: power cards as a list of strings
    '''

    # create a list with the correct values
    power_cards = ['SOH'] * 10 + ['DOT'] * 2 + ['DMT'] * 3

    # shuffle the list
    shuffle(power_cards)

    # return the shuffled list of integers
    return power_cards

def setup_cards():
    '''
    Sets up both the water card and power card piles as described in the setup_water_cards and setup_power_cards functions.
    Returns: 2-tuple containing the water cards pile and the power cards pile, respectively (each pile is represented by a list)
    '''

    #Get a shuffled list of water cards with correct values
    water_cards = setup_water_cards()

    #Get a shuffled list of power cards with correct values
    power_cards = setup_power_cards()

    #Create a 2-tuple containing the list of water cards and power cards
    cards = (water_cards, power_cards)

    #Return the 2-tuple
    return cards

def get_card_from_pile(pile, index):
    '''
    Removes the entry at the specified index of the given pile (water or power) and modifies the pile by reference.
    Parameters:
        - pile is a list of either water cards or power cards
        - index is an int representing the index of the card to be removed in the given pile
    Returns: the entry at the specified index
    '''

    #Get the entry at the specified index
    entry = pile[index]

    #Remove the entry at the specified index of the given pile
    pile.pop(index)

    #Return the entry at the specified index
    return entry

def arrange_cards(cards_list):
    '''
    Arranges the players cards such that:
        - The first three indices are water cards, sorted in ascending order
        - The last two indices are power cards, sorted in alphabetical order
    Parameters: cards_list is a list of 5 cards (including int water cards and string power cards)
    Returns: None
    '''

    #First, check if each value in the list is an instance of the string class
    #If yes, then it will return a value of True, and if no, it will return a value of False
    #False gets placed before True in a list, so this will place the integers before the strings
    #Then, sort by the value (numerical order for integers and lexicographical order for the strings
    #Note: The sort function changes the reference to the list
    cards_list.sort(key=lambda x: (isinstance(x, str), x))

def deal_cards(water_cards_pile, power_cards_pile):
    '''
    Deals cards to player 1 and player 2 by alternately taking off a card from the first entry in the pile.
    Starts by alternately taking off a card from the first entry of the water pile until each player gets 3 water cards.
    Then, alternately takes off a card from the first entry of the power pile until each player gets 2 power cards.
    Finally, calls the arrange_cards function to arrange the cards.
    Parameters:
        - water_cards_pile: list of ints holding the values of the water cards
        - power_cards_pile: list of strings holding the types of power cards
    Returns: 2-tuple containing the player 1's hand (represented as a list) and player 2's hand (represented as a list)
    '''

    #initialize empty lists to store each player's cards
    player_1_cards = []
    player_2_cards = []

    #Continue the loop while the length of player 2's cards is less than 3, because we deal cards to player 2 second,
    #and both players need 3 cards
    while len(player_2_cards) < 3:
        #Add the first value to player 1's list
        player_1_cards.append(water_cards_pile[0])
        #Remove that value from the water pile
        water_cards_pile.pop(0)
        #Add the new first value to player 2's list
        player_2_cards.append(water_cards_pile[0])
        #Remove that value from the water pile
        water_cards_pile.pop(0)

    #Continue the loop while the length of player 2's cards is less than 5, because we deal cards to player 2 second,
    #and both players need 5 cards once both water and power cards are dealt
    while len(player_2_cards) < 5:
        #Add the first value to player 1's list
        player_1_cards.append(power_cards_pile[0])
        #Remove that value from the power pile
        power_cards_pile.pop(0)
        #Add the new first value to player 2's list
        player_2_cards.append(power_cards_pile[0])
        # Remove that value from the power pile
        power_cards_pile.pop(0)

    #Arrange player 1's cards. We don't need to store it in a new variable because the arrange function will change the reference.
    arrange_cards(player_1_cards)

    #Arrange player 2's cards. We don't need to store it in a new variable because the arrange function will change the reference.
    arrange_cards(player_2_cards)

    #Return a 2-tuple containing both lists
    return (player_1_cards, player_2_cards)


def apply_overflow(tank_level):
    '''
    Applies the following overflow rule if player reaches water tank level above 80:
        remaining water = maximum fill value - overflow
    Parameter: integer representing the tank level
    Returns: integer representing the new tank level after the formula has been applied. If no overflow occurred, this is the starting tank level.
    '''

    #Initialize new_tank_level with a default value
    new_tank_level = tank_level

    #Check if the water tank level is above 80
    if tank_level > 80:
        #Calculate the overflow
        overflow = tank_level - 80

        #Use the formula to find the new tank level
        new_tank_level = 80 - overflow

    return new_tank_level


def use_card(player_tank, card_to_use, player_cards, opponent_tank):
    '''
    Gets the card_to_use from the player's hand and updates the tank level based on the card that was used.
    Note: This does not include drawing a replacement card, so after using the card, the players_cards size will only be 4 cards.
    Applies overflow if necessary.
    Parameters:
        - player_tank: int representing the water level in the player's tank
        - card_to_use: either an int or a string representing which water or power card to use
        - players_cards: list of ints and strings representing the water and power cards the player has
        - opponent_tank: list of ints and strings representing the water and power cards the opponent has
    Returns: 2-tuple containing the player's tank (int) and opponent's tank (int), respectively
    '''

    #If the player chose a water card, add the value of the water card to their tank
    if isinstance(card_to_use, int):
        player_tank += card_to_use

    #If the player chose the SOH power card, steal half of the opponent's tank
    elif card_to_use == "SOH":
        #Calculate the value of half of the opponent's tank, discard the remainder, and store it in a variable
        opponents_half = opponent_tank//2
        #Half the opponents tank
        opponent_tank -= opponents_half
        #Add the opponent's half to player's tank
        player_tank += opponents_half

    #If the player chose the DOT power card, drain the opponent's tank by setting it back to 0
    elif card_to_use == "DOT":
        opponent_tank = 0

    #If the player chose the DMT power card, double the player's tank
    elif card_to_use == "DMT":
        player_tank *= 2

    # Remove the card the player used from their hand
    player_cards.remove(card_to_use)

    #Check for the player's tank overflow and apply that to the player's tank level
    player_tank = apply_overflow(player_tank)
    #Check for opponent's tank overflow and apply that to the opponent's tank level
    opponent_tank = apply_overflow(opponent_tank)

    #Return 2-tuple containing player's tank and opponent's tank
    return (player_tank, opponent_tank)

def check_card(player_tank, card_to_use, players_cards, opponent_tank):
    '''
    Checks the card the player is using and returns the water levels for that card
    Does not update the player's cards as this is only a test-check, not the actual play
    Note: This is different from the use_card function because you will NOT remove the card you are testing from the player's cards
    Parameters:
        - player_tank: int representing the water level in the player's tank
        - card_to_use: either an int or a string representing which water or power card to use
        - players_cards: list of ints and strings representing the water and power cards the player has
        - opponent_tank: list of ints and strings representing the water and power cards the opponent has
    Returns: 2-tuple containing the player's tank (int) and opponent's tank (int), respectively
    '''

    #If the player chose a water card, add the value of the water card to their tank
    if isinstance(card_to_use, int):
        player_tank += card_to_use

    #If the player chose the SOH power card, steal half of the opponent's tank
    elif card_to_use == "SOH":
        #Calculate the value of half of the opponent's tank, discard the remainder, and store it in a variable
        opponents_half = opponent_tank // 2
        #Half the opponents tank
        opponent_tank -= opponents_half
        #Add the opponent's half to player's tank
        player_tank += opponents_half


    #If the player chose the DOT power card, drain the opponent's tank by setting it back to 0
    elif card_to_use == "DOT":
        opponent_tank = 0


    #If the player chose the DMT power card, double the player's tank
    elif card_to_use == "DMT":
        player_tank *= 2


    #Check for the player's tank overflow and apply that to the player's tank level
    updated_player_tank = apply_overflow(player_tank)

    #Check for opponent's tank overflow and apply that to the opponent's tank level
    updated_opponent_tank = apply_overflow(opponent_tank)

    #Return 2-tuple containing player's tank and opponent's tank
    return (updated_player_tank, updated_opponent_tank)

def discard_card(card_to_discard, player_cards, water_cards_pile, power_cards_pile):
    '''
    Discards the given card from the player's hand and returns it to the bottom of the appropriate pile (last index of the list).
    Note: this function does not include drawing a replacement card, so after calling the function, the player_cards size will only be 4 cards.
    Parameters:
        - card_to_discard: either an int or a string representing which water or power card to discard
        - player_cards: list of ints and strings representing the water and power cards the player has
        - water_cards_pile: list of ints representing the values of the water cards
        - power_cards_pile: list of strings representing the values of the power cards
    Returns: None
    '''

    #Find the index of the card to discard
    index_of_card_to_discard = player_cards.index(card_to_discard)

    #Remove the card from the player's hand
    player_cards.pop(index_of_card_to_discard)

    #If the card to discard is an integer, return it to the bottom of the water pile
    if isinstance(card_to_discard, int):
        water_cards_pile.append(card_to_discard)
    #Otherwise, if the card to discard is a string, return it to the bottom of the power pile
    else:
        power_cards_pile.append(card_to_discard)


def draw_replacement_card(card, player_cards, water_cards_pile, power_cards_pile, player):
    '''
    Draws a new card of the same type once the player has used or discarded their card. Adds card to the list of the player's cards.
    Prints a message stating what card player is drawing (water or power) and value of the card.
    Parameters:
        - card: int or string representing the card the user is discarding
        - player_cards: list of ints and strings representing the water and power cards the player has
        - water_cards_pile: list of ints representing values of water cards
        - power_cards_pile: list of strings representing values of power cards
        - player: string listing which player is currently drawing a replacement card (either "human" or "computer)
    Returns: None
    '''

    #If the card is an integer, draw a new water card
    if isinstance(card, int):
        # Add the first value of the water card's pile to the player's list
        player_cards.append(water_cards_pile[0])

        #Print a message stating which card the player drew only if the player is human (we don't want to reveal which card the computer drew)
        if player == "human":
            print("Drawing water card: " + str(water_cards_pile[0]))

        # Remove that card from the water pile
        water_cards_pile.pop(0)

    #Otherwise, if the card is a string, draw a new power card
    else:
        # Add the first value of the power card's pile to the player's list
        player_cards.append(power_cards_pile[0])

        #Print a message stating which card the player drew only if the player is human (we don't want to reveal which card the computer drew)
        if player == "human":
            print("Drawing power card: " + power_cards_pile[0])

        # Remove that card from the power pile
        power_cards_pile.pop(0)


def filled_tank(tank):
    '''
    Determines if the tank level is between the maximum and minimum fill values (75 to 80 inclusive).
    Parameter: tank is an int representing the water level in the tank
    Returns: boolean representing whether the tank is filled (True if tank is filled, False if not)
    '''

    #Check if the tank level is between 75 and 80. If so, return true, Otherwise, return False.
    if 75 <= tank <= 80:
        return True
    else:
        return False

def check_pile(pile, pile_type):
    '''
    Checks if the given pile is empty. If so, calls the pile's setup function to replenish the pile.
    Parameters:
        - pile: list of ints or strings representing either the water cards or power cards
        - pile_type: string to determine what type of pile you are checking ("water" or "power")
    Returns: None
    '''

    #Check if the list is empty
    if len(pile) == 0:
        #If the list is empty, and it's a pile of water cards, set up the water pile again and extend the empty water pile list with this list
        if pile_type == "water":
            pile.extend(setup_water_cards())

        # If the list is empty, and it's a pile of power cards, set up the power pile again and extend the empty power pile list with this list
        else:
            pile.extend(setup_power_cards())

def print_win_message(winning_player):
    '''
    Prints a message stating which player won and that the game is over.
    Parameter: winning_player is a string representing which player won (either "Human Player" or "Computer Player")
    Returns: end-of-game/winning message in the form of a string
    '''

    #Print message stating that the game is over and indicating which player won
    print("=== Game Over ===")
    print(winning_player + " won")

def human_play(human_tank, human_cards, water_cards_pile, power_cards_pile, opponent_tank):
    '''
    Allows the human user to make their play by following these steps:
        1. Shows the human player's water level and then the computer player's water level.
        2. Shows the human player their hand and asks them if they want to use or discard a card (gets user input with use_or_discard function).
            - If the human player enters an invalid answer, reprompts until a valid answer is entered.
        3. Carries out the human's turn based on the action they have chosen (gets user input with the get_user_input function).
        4. Prints the card the human player uses or discards.
            - If the human player enters a card to use or discard which is not in their hand, reprompts until a valid card is entered.
        5. Handles potential overflows (use apply_overflow function).
        6. Draws a new card of the same type once the human has used or discarded their card (use draw_replacement_card function).
        7. Makes sure that the human's hand is still properly arranged after adding the new card (use arrange_cards function).
    Parameters:
        - human_tank: integer representing the water level of the human's tank
        - human_cards: list of either ints and/or strings representing values of water and/or power cards.
        - water_cards_pile: list of ints representing the values of water cards in the pile
        - power_cards_pile: list of strings representing the values of power cards in the pile
        - opponent_tank: integer representing the water level of the opponent's tank
    Returns: 2-tuple containing the human's tank level and computer's tank level, respectively.
    '''

    #Show the human player's water level
    print("Your water level is at: " + str(human_tank))
    #Show th computer player's water level
    print("Computer's water level is at: " + str(opponent_tank))
    #Show the human player their hand
    print("Your cards are: " + str(human_cards))

    #Ask the human player whether they want to use or discard their card
    answer = use_or_discard("Do you want to use or discard a card? (u/d): ")

    #If the human player chooses to discard their card, call the discard_card function
    if answer == "d":
        #Get the card the user wants to discard by calling the get_card_to_discard function and storing it in a variable
        card_to_discard = get_card_to_discard(human_cards)

        #Print the card the user wants to discard
        print("Discarding card: " + str(card_to_discard))

        #Discard the card using the discard_card function
        discard_card(card_to_discard, human_cards, water_cards_pile, power_cards_pile)

        #Draw a replacement card
        draw_replacement_card(card_to_discard, human_cards, water_cards_pile, power_cards_pile, "human")

        #Makes sure human's hand is still properly arranged after drawing a replacement card
        arrange_cards(human_cards)

        # Print human player's new cards
        print("Your cards are now " + str(human_cards) + "\n")


#Otherwise, if the human player chooses to use their card, ask them which card they want to use
    else:
        card_to_use = get_user_input("Which card do you want to use? ")

        #While the user chooses a card that's not in their hand, return an error message and get user input again
        while card_to_use not in human_cards:
            print("You do not have the card you chose. Please choose a card from the ones listed.")
            card_to_use = get_user_input("Which card do you want to use? ")

        #Print the card to use
        print("Playing with card: " + str(card_to_use))

        #Call the use_card function to use the card chosen and assign the returned water levels to their respective tanks
        human_tank, opponent_tank = use_card(human_tank, card_to_use, human_cards, opponent_tank)

        #Print human's water level
        print("Your water level is now at: " + str(human_tank))
        #Print computer's water level
        print("Computer's water level is now at: " + str(opponent_tank))

        #Draw a replacement card
        draw_replacement_card(card_to_use, human_cards, water_cards_pile, power_cards_pile, "human")

        #Makes sure human's hand is still properly arranged after drawing a replacement card
        arrange_cards(human_cards)

        # Print human player's new cards
        print("Your cards are now " + str(human_cards) + "\n")

    #Return 2-tuple containing human tank levels and computer tank levels
    return (human_tank, opponent_tank)

def computer_play(computer_tank, computer_cards, water_cards_pile, power_cards_pile, opponent_tank):
    '''
    Defines a strategy for the computer to implement when it is their turn.
    Carries out the computer's turn based on the action they have chosen.
    Prints the card the computer player uses or discards.
    Handles potential overflows (use apply_overflow function).
    Draws a new card of the same type once the computer has used or discarded their card (use draw_replacement_card function).
    Makes sure that the computer's hand is still properly arranged after adding the new card (use arrange_cards function).
    Parameters:
        - computer_tank: integer representing the water level of the computer's tank
        - computer_cards: list of either ints and/or strings representing values of water and/or power cards.
        - water_cards_pile: list of ints representing the values of water cards in the pile
        - power_cards_pile: list of strings representing the values of power cards in the pile
        - opponent_tank: integer representing the water level of the opponent's tank
    Returns: 2-tuple containing the human's tank level and computer's tank level, respectively.
    '''

    #Show the computer player's water level
    print("Computer's water level is at: " + str(computer_tank))
    #Show the human player's water level
    print("Your water level is at: " + str(opponent_tank))

    # Initialize a variable to store the best card
    best_card = None
    # Initialize a variable to store the computer's tank level
    best_result = computer_tank

    #STRATEGY FOR COMPUTER:

    #First, try to see if the computer could win by using a water card
    for card in computer_cards:
        #Check if the card is a water card by checking if it is an integer
        if isinstance(card, int):
            #Check if adding the water card to the computer tank level will lead to a win
            #If the water level is 85, the overflow will be 5, so the new tank level according to the overflow formula will be 75, which is still a win
            if 75 <= computer_tank + card <= 85:
                best_card = card
                break

    #If the computer can't win with a water card, try if the computer can win with a power card
    if best_card is None:
        for card in computer_cards:
            #Check if the 'DMT' card will lead to a win or an overflow
            if card == 'DMT' and computer_tank * 2 >= 75:
                best_card = card
                break
            #Check if the 'SOH' card will lead to a win or an overflow
            elif card == "SOH" and (opponent_tank//2) + computer_tank >= 75:
                best_card = card
                break

    #If there is no immediate win after testing water cards and power cards, prioritize finding the best play (first prioritize power cards then water cards)
    if best_card is None:
        #Prioritize DOT if opponent has a water level greater than 60
        if 'DOT' in computer_cards and opponent_tank > 60:
            best_card = 'DOT'

    #Move to the next power card if DOT did not apply
    if best_card is None:
        #Prioritize DMT if this results in a better tank level than the current tank level
        if 'DMT' in computer_cards:
            #See what water level using 'DMT' will result in
            new_computer_tank = check_card(computer_tank, 'DMT', computer_cards, opponent_tank)[0]
            #If the water level is greater than the current level, store this as the best card and update the best result
            if new_computer_tank > best_result:
                best_card = 'DMT'
                best_result = new_computer_tank

        #Next, prioritize SOH if stealing the opponent's half improves the tank more than doubling your tank
        if 'SOH' in computer_cards:
            #See what water level using 'SOH' will result in
            new_computer_tank = check_card(computer_tank, 'SOH', computer_cards, opponent_tank)[0]
            #If the water level is greater than the current highest level, store this as the best card and update the best result
            if new_computer_tank > best_result:
                best_card = 'SOH'
                best_result = new_computer_tank

        #Check to see if highest water card will lead to a higher or equal water level than the power cards
        best_water_card = max(card for card in computer_cards if isinstance(card, int))
        new_computer_tank = check_card(computer_tank, best_water_card, computer_cards, opponent_tank)[0]
        if new_computer_tank >= best_result:
            best_card = best_water_card
            best_result = new_computer_tank

    #If no power cards DMT or SOH power cards in tank, play the highest value water card
    if best_card is None:
        best_water_card = max(card for card in computer_cards if isinstance(card, int))
        best_card = best_water_card


    #Print a message stating which card the computer is playing with based on the index you stored
    print("Computer playing with card:", best_card)

    #Call the use_card function to use the card chosen and assign the returned water levels to their respective tanks
    computer_tank, opponent_tank = use_card(computer_tank, best_card, computer_cards, opponent_tank)

    #Apply overflow and update computer_tank variable
    computer_tank = apply_overflow(computer_tank)

    #Draw a replacement card
    draw_replacement_card(best_card, computer_cards, water_cards_pile, power_cards_pile, "computer")

    #Makes sure computer's hand is still properly arranged after drawing a replacement card
    arrange_cards(computer_cards)


    #Return 2-tuple containing human's tank level and computer's tank level
    return (computer_tank, opponent_tank)


def main():
    '''
    Carries out the water tank game using the following steps:
        1. Prints game instructions using the print_game_instructions function.
        2. Chooses which player goes randomly using the get_random_player function.
        3. Sets up the total cards using the setup_cards function, which calls the setup_water_cards and setup_power_cards functions.
        4. Deal the cards to each player using the deal_cards function, which calls the arrange_cards function to arrange the cards.
        5. Get the first play by calling either the human_play function or computer_play function.
        6. Checks if the player won by calling the filled_tank function. Prints a win message if user won using the print_win_message function.
        7. Replenishes card piles if empty by calling the check_pile function.
        8. Takes other player's play.
        9. Repeats process until a player wins.
    '''

    #Print game instructions
    print_game_instructions()

    #Choose which player goes randomly
    player = get_random_player()

    #Print message stating which player is starting
    print("The", player, "has been selected to go first.\n")

    #Set up the cards and assign the 2-tuple of water cards and power cards to a variable
    total_cards = setup_cards()

    #Assign the list of water cards to a variable
    water_pile = total_cards[0]

    #Assign the list of power cards to a variable
    power_pile = total_cards[1]

    #Deal cards by passing in the water cards and power cards. Set the list to variables representing both player's cards
    player_1_cards, player_2_cards = deal_cards(water_pile, power_pile)

    #Assign the cards to the correct player based on who got chosen to play first
    if player == "Human Player":
        human_cards = player_1_cards
        computer_cards = player_2_cards
    else:
        computer_cards = player_1_cards
        human_cards = player_2_cards

    #Initialize variables to hold the water level in the tank for each player.
    human_tank = 0
    computer_tank = 0

    #Initialize a win variable to False. This will be switched to True once a player wins the game.
    win = False

    while win == False:

        # Replenish the water card pile if empty
        check_pile(water_pile, "water")
        # Replenish the power card pile if empty
        check_pile(power_pile, "power")

        #Get the first player by calling either the human play or computer play function, based on which player is starting
        if player == "Human Player":

            #Print message stating that it is the human player's turn
            print("=== Human Player's turn ===")

            #If the current player is the human player, execute a human play
            #Update the tank level variable (human_play returns 2-tuple of tank levels)
            human_tank, computer_tank = human_play(human_tank, human_cards, water_pile, power_pile, computer_tank)

            #Check if the player won using the filled_tank function and set the value to variable "win".
            #This will also break the while loop if the player won.
            win = filled_tank(human_tank)

            #If the player won, print the win message by calling the print_win_message function and passing in the winning player
            if win == True:
                print_win_message(player)

            #Switch players once the human player had their turn
            player = "Computer Player"

        #Otherwise, if the current player is the computer player, execute a computer play
        else:

            # Print message stating that it is the computer player's turn
            print("=== Computer Player's turn ===")

            #If the current player is the computer player, execute a computer play
            #Update the tank level variable (human_play returns 2-tuple of tank levels)
            computer_tank, human_tank = computer_play(computer_tank, computer_cards, water_pile, power_pile, human_tank)

            # Print computer's water level
            print("Computer's water level is now at: " + str(computer_tank))

            # Print human's water level
            print("Your water level is now at: " + str(human_tank) + "\n")

            # Check if the player won using the filled_tank function and set the value to variable "win".
            # This will also break the while loop if the player won.
            win = filled_tank(computer_tank)
            # If the player won, print the win message by calling the print_win_message function and passing in the winning player
            if win == True:
                print_win_message(player)

            # Switch players once the computer player had their turn
            player = "Human Player"

#entry point
if __name__ == '__main__':
    main()
